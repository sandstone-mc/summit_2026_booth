import type { TextStyle } from 'sandstone/arguments/generated/util/text.ts'

export type ChatDecoration = ({
  translation_key: string,
  parameters: Array<ChatDecorationParameter>,
} & {
  style?: TextStyle,
})

export type ChatDecorationParameter = ('sender' | 'content' | 'team_name' | 'target')

export type ChatType = {
  chat: ChatDecoration,
  narration: ChatDecoration,
}

export type Narration = {
  decoration?: ChatDecoration,
  /**
   * Value:
   *
   *  - Chat(`chat`)
   *  - System(`system`)
   */
  priority: NarrationPriority,
}

export type NarrationPriority = ('chat' | 'system')

export type OldChatType = {
  chat?: TextDisplay,
  overlay?: TextDisplay,
  narration?: Narration,
}

export type TextDisplay = {
  decoration?: ChatDecoration,
}
