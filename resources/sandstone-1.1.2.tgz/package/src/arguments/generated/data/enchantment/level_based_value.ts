import type { Registry } from 'sandstone/arguments/generated/registry.ts'
import type { RootNBT } from 'sandstone/arguments/nbt.ts'
import type { NBTFloat, NBTList } from 'sandstone'

export type ClampedLevelValue = {
  value: LevelBasedValue,
  min: NBTFloat,
  max: NBTFloat,
}

export type ExponentLevelValue = {
  base: LevelBasedValue,
  power: LevelBasedValue,
}

export type FractionLevelValue = {
  numerator: LevelBasedValue,
  denominator: LevelBasedValue,
}

export type LevelBasedValue = (NBTFloat | LevelBasedValueMap)

export type LevelBasedValueMap = NonNullable<({
  [S in Extract<Extract<Registry['minecraft:enchantment_level_based_value_type'], string>, string>]?: ({
    type: S,
  } & (S extends keyof SymbolLevelBasedValue ? SymbolLevelBasedValue[S] : RootNBT))
}[Extract<Registry['minecraft:enchantment_level_based_value_type'], string>])>

export type LinearLevelValue = {
  /**
   * Base value at level 1.
   */
  base: NBTFloat,
  /**
   * Value increase per level above 1.
   */
  per_level_above_first: NBTFloat,
}

export type LookupLevelValue = {
  /**
   * Indexed by `level - 1` to apply, if present
   *
   * Value:
   * List length range: 1..
   */
  values: NBTList<LevelBasedValue, {
    leftExclusive: false,
    min: 1,
  }>,
  /**
   * Applied if the level is greater than the size of `values`.
   */
  fallback: LevelBasedValue,
}

export type SquaredLevelValue = {
  /**
   * Added to the result so that the result becomes `square(level) + added`.
   */
  added: NBTFloat,
}
type LevelBasedValueDispatcherMap = {
  'clamped': LevelBasedValueClamped,
  'minecraft:clamped': LevelBasedValueClamped,
  'exponent': LevelBasedValueExponent,
  'minecraft:exponent': LevelBasedValueExponent,
  'fraction': LevelBasedValueFraction,
  'minecraft:fraction': LevelBasedValueFraction,
  'levels_squared': LevelBasedValueLevelsSquared,
  'minecraft:levels_squared': LevelBasedValueLevelsSquared,
  'linear': LevelBasedValueLinear,
  'minecraft:linear': LevelBasedValueLinear,
  'lookup': LevelBasedValueLookup,
  'minecraft:lookup': LevelBasedValueLookup,
}
type LevelBasedValueKeys = keyof LevelBasedValueDispatcherMap
type LevelBasedValueFallback = (
  | LevelBasedValueClamped
  | LevelBasedValueExponent
  | LevelBasedValueFraction
  | LevelBasedValueLevelsSquared
  | LevelBasedValueLinear
  | LevelBasedValueLookup)
type LevelBasedValueClamped = ClampedLevelValue
type LevelBasedValueExponent = ExponentLevelValue
type LevelBasedValueFraction = FractionLevelValue
type LevelBasedValueLevelsSquared = SquaredLevelValue
type LevelBasedValueLinear = LinearLevelValue
type LevelBasedValueLookup = LookupLevelValue
export type SymbolLevelBasedValue<CASE extends
  | 'map'
  | 'keys'
  | '%fallback'
  | '%none'
  | '%unknown' = 'map'> = CASE extends 'map'
  ? LevelBasedValueDispatcherMap
  : CASE extends 'keys' ? LevelBasedValueKeys : CASE extends '%fallback' ? LevelBasedValueFallback : never
