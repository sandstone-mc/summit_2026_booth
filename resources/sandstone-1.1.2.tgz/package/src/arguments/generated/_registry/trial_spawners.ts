import { Set } from 'sandstone'
import type { NamespacedLiteralUnion, SetType } from 'sandstone'

export type TRIAL_SPAWNERS = (
  | NamespacedLiteralUnion<SetType<typeof TRIAL_SPAWNERS_SET>>
  | `minecraft:${SetType<typeof TRIAL_SPAWNERS_SET>}`)

export const TRIAL_SPAWNERS_SET = new Set([
  'trial_chamber/breeze/normal',
  'trial_chamber/breeze/ominous',
  'trial_chamber/melee/husk/normal',
  'trial_chamber/melee/husk/ominous',
  'trial_chamber/melee/spider/normal',
  'trial_chamber/melee/spider/ominous',
  'trial_chamber/melee/zombie/normal',
  'trial_chamber/melee/zombie/ominous',
  'trial_chamber/ranged/poison_skeleton/normal',
  'trial_chamber/ranged/poison_skeleton/ominous',
  'trial_chamber/ranged/skeleton/normal',
  'trial_chamber/ranged/skeleton/ominous',
  'trial_chamber/ranged/stray/normal',
  'trial_chamber/ranged/stray/ominous',
  'trial_chamber/slow_ranged/poison_skeleton/normal',
  'trial_chamber/slow_ranged/poison_skeleton/ominous',
  'trial_chamber/slow_ranged/skeleton/normal',
  'trial_chamber/slow_ranged/skeleton/ominous',
  'trial_chamber/slow_ranged/stray/normal',
  'trial_chamber/slow_ranged/stray/ominous',
  'trial_chamber/small_melee/baby_zombie/normal',
  'trial_chamber/small_melee/baby_zombie/ominous',
  'trial_chamber/small_melee/cave_spider/normal',
  'trial_chamber/small_melee/cave_spider/ominous',
  'trial_chamber/small_melee/silverfish/normal',
  'trial_chamber/small_melee/silverfish/ominous',
  'trial_chamber/small_melee/slime/normal',
  'trial_chamber/small_melee/slime/ominous',
] as const)
