import { Set } from 'sandstone'
import type { NamespacedLiteralUnion, SetType } from 'sandstone'

export type TAG_DAMAGE_TYPES = (
  | NamespacedLiteralUnion<SetType<typeof TAG_DAMAGE_TYPES_SET>>
  | `minecraft:${SetType<typeof TAG_DAMAGE_TYPES_SET>}`)

export const TAG_DAMAGE_TYPES_SET = new Set([
  'always_hurts_ender_dragons',
  'always_kills_armor_stands',
  'always_most_significant_fall',
  'always_triggers_silverfish',
  'avoids_guardian_thorns',
  'burn_from_stepping',
  'burns_armor_stands',
  'bypasses_armor',
  'bypasses_effects',
  'bypasses_enchantments',
  'bypasses_invulnerability',
  'bypasses_resistance',
  'bypasses_shield',
  'bypasses_wolf_armor',
  'can_break_armor_stand',
  'damages_helmet',
  'ignites_armor_stands',
  'is_drowning',
  'is_explosion',
  'is_fall',
  'is_fire',
  'is_freezing',
  'is_lightning',
  'is_player_attack',
  'is_projectile',
  'mace_smash',
  'no_anger',
  'no_impact',
  'no_knockback',
  'panic_causes',
  'panic_environmental_causes',
  'sulfur_cube_with_block_immune_to',
  'witch_resistant_to',
  'wither_immune_to',
] as const)
