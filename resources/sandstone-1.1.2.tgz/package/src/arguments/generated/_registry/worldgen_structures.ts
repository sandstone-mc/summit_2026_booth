import { Set } from 'sandstone'
import type { NamespacedLiteralUnion, SetType } from 'sandstone'

export type WORLDGEN_STRUCTURES = (
  | NamespacedLiteralUnion<SetType<typeof WORLDGEN_STRUCTURES_SET>>
  | `minecraft:${SetType<typeof WORLDGEN_STRUCTURES_SET>}`)

export const WORLDGEN_STRUCTURES_SET = new Set([
  'ancient_city',
  'bastion_remnant',
  'buried_treasure',
  'desert_pyramid',
  'end_city',
  'fortress',
  'igloo',
  'jungle_pyramid',
  'mansion',
  'mineshaft',
  'mineshaft_mesa',
  'monument',
  'nether_fossil',
  'ocean_ruin_cold',
  'ocean_ruin_warm',
  'pillager_outpost',
  'ruined_portal',
  'ruined_portal_desert',
  'ruined_portal_jungle',
  'ruined_portal_mountain',
  'ruined_portal_nether',
  'ruined_portal_ocean',
  'ruined_portal_swamp',
  'shipwreck',
  'shipwreck_beached',
  'stronghold',
  'swamp_hut',
  'trail_ruins',
  'trial_chambers',
  'village_desert',
  'village_plains',
  'village_savanna',
  'village_snowy',
  'village_taiga',
] as const)
