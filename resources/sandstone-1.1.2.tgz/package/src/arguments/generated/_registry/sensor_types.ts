import { Set } from 'sandstone'
import type { NamespacedLiteralUnion, SetType } from 'sandstone'

export type SENSOR_TYPES = (
  | NamespacedLiteralUnion<SetType<typeof SENSOR_TYPES_SET>>
  | `minecraft:${SetType<typeof SENSOR_TYPES_SET>}`)

export const SENSOR_TYPES_SET = new Set([
  'armadillo_scare_detected',
  'axolotl_attackables',
  'breeze_attack_entity_sensor',
  'dummy',
  'food_temptations',
  'frog_attackables',
  'frog_temptations',
  'golem_detected',
  'hoglin_specific_sensor',
  'hurt_by',
  'is_in_water',
  'nautilus_temptations',
  'nearest_adult',
  'nearest_adult_any_type',
  'nearest_bed',
  'nearest_items',
  'nearest_living_entities',
  'nearest_players',
  'piglin_brute_specific_sensor',
  'piglin_specific_sensor',
  'secondary_pois',
  'villager_babies',
  'villager_hostiles',
  'warden_entity_sensor',
] as const)
