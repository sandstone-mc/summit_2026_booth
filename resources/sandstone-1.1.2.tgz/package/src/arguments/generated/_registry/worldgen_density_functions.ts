import { Set } from 'sandstone'
import type { NamespacedLiteralUnion, SetType } from 'sandstone'

export type WORLDGEN_DENSITY_FUNCTIONS = (
  | NamespacedLiteralUnion<SetType<typeof WORLDGEN_DENSITY_FUNCTIONS_SET>>
  | `minecraft:${SetType<typeof WORLDGEN_DENSITY_FUNCTIONS_SET>}`)

export const WORLDGEN_DENSITY_FUNCTIONS_SET = new Set([
  'end/base_3d_noise',
  'end/sloped_cheese',
  'nether/base_3d_noise',
  'overworld/base_3d_noise',
  'overworld/caves/entrances',
  'overworld/caves/noodle',
  'overworld/caves/pillars',
  'overworld/caves/spaghetti_2d',
  'overworld/caves/spaghetti_2d_thickness_modulator',
  'overworld/caves/spaghetti_roughness_function',
  'overworld/continents',
  'overworld/depth',
  'overworld/erosion',
  'overworld/factor',
  'overworld/jaggedness',
  'overworld/offset',
  'overworld/ridges',
  'overworld/ridges_folded',
  'overworld/sloped_cheese',
  'overworld_amplified/depth',
  'overworld_amplified/factor',
  'overworld_amplified/jaggedness',
  'overworld_amplified/offset',
  'overworld_amplified/sloped_cheese',
  'overworld_large_biomes/continents',
  'overworld_large_biomes/depth',
  'overworld_large_biomes/erosion',
  'overworld_large_biomes/factor',
  'overworld_large_biomes/jaggedness',
  'overworld_large_biomes/offset',
  'overworld_large_biomes/sloped_cheese',
  'shift_x',
  'shift_z',
  'y',
  'zero',
] as const)
