import { Set } from 'sandstone'
import type { NamespacedLiteralUnion, SetType } from 'sandstone'

export type WORLDGEN_PROCESSOR_LISTS = (
  | NamespacedLiteralUnion<SetType<typeof WORLDGEN_PROCESSOR_LISTS_SET>>
  | `minecraft:${SetType<typeof WORLDGEN_PROCESSOR_LISTS_SET>}`)

export const WORLDGEN_PROCESSOR_LISTS_SET = new Set([
  'ancient_city_generic_degradation',
  'ancient_city_start_degradation',
  'ancient_city_walls_degradation',
  'bastion_generic_degradation',
  'bottom_rampart',
  'bridge',
  'empty',
  'entrance_replacement',
  'farm_desert',
  'farm_plains',
  'farm_savanna',
  'farm_snowy',
  'farm_taiga',
  'fossil_coal',
  'fossil_diamonds',
  'fossil_rot',
  'high_rampart',
  'high_wall',
  'housing',
  'mossify_10_percent',
  'mossify_20_percent',
  'mossify_70_percent',
  'outpost_rot',
  'rampart_degradation',
  'roof',
  'side_wall_degradation',
  'stable_degradation',
  'street_plains',
  'street_savanna',
  'street_snowy_or_taiga',
  'trail_ruins_houses_archaeology',
  'trail_ruins_roads_archaeology',
  'trail_ruins_tower_top_archaeology',
  'treasure_rooms',
  'trial_chambers_copper_bulb_degradation',
  'zombie_desert',
  'zombie_plains',
  'zombie_savanna',
  'zombie_snowy',
  'zombie_taiga',
] as const)
