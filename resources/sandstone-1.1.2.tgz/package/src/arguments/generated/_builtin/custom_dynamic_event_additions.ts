import type { UnknownDynamicAdditions } from 'sandstone/arguments/generated/util/custom_event.ts'

type McdocCustomDynamicEventAdditionsDispatcherMap = {}
type McdocCustomDynamicEventAdditionsKeys = keyof McdocCustomDynamicEventAdditionsDispatcherMap
type McdocCustomDynamicEventAdditionsFallback = (McdocCustomDynamicEventAdditionsFallbackType)
export type McdocCustomDynamicEventAdditionsFallbackType = UnknownDynamicAdditions

export type SymbolMcdocCustomDynamicEventAdditions<CASE extends
  | 'map'
  | 'keys'
  | '%fallback'
  | '%none'
  | '%unknown' = 'map'> = CASE extends 'map'
  ? McdocCustomDynamicEventAdditionsDispatcherMap
  : CASE extends 'keys'
    ? McdocCustomDynamicEventAdditionsKeys
    : CASE extends '%fallback'
      ? McdocCustomDynamicEventAdditionsFallback
      : CASE extends '%unknown' ? McdocCustomDynamicEventAdditionsFallbackType : never
