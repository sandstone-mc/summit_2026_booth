import type {
  EnchantmentPredicate,
  EntityEffectsPredicate,
  ItemPredicate,
} from 'sandstone/arguments/generated/data/advancement/predicate.ts'
import type { MinMaxBounds } from 'sandstone/arguments/generated/data/util.ts'
import type { Registry } from 'sandstone/arguments/generated/registry.ts'
import type { AttributeOperation } from 'sandstone/arguments/generated/util/attribute.ts'
import type { EquipmentSlotGroup } from 'sandstone/arguments/generated/util/slot.ts'
import type { Text } from 'sandstone/arguments/generated/util/text.ts'
import type { CustomData } from 'sandstone/arguments/generated/world/component.ts'
import type { FireworkShape } from 'sandstone/arguments/generated/world/component/item.ts'
import type { NBTObject } from 'sandstone/arguments/nbt.ts'
import type { JukeboxSongClass, NBTDouble, NBTInt, TagClass, TrimMaterialClass, TrimPatternClass } from 'sandstone'

export type AttributeModifiersPredicate = {
  modifiers?: CollectionPredicate<AttributeModifiersPredicateEntry>,
}

export type AttributeModifiersPredicateEntry = {
  attribute?: ((
      | Registry['minecraft:attribute'] | `#${string}:${string}` | TagClass<'attribute'>)
      | Array<Registry['minecraft:attribute']>),
  id?: `${string}:${string}`,
  amount?: MinMaxBounds<(NBTDouble | number)>,
  /**
   * Value:
   *
   *  - AddValue(`add_value`): Adds all of the modifiers' amounts to the current value of the attribute.
   *  - AddMultipliedBase(`add_multiplied_base`):
   *    Multiplies the current value of the attribute by `(1 + x)`,
   *    where `x` is the sum of the modifiers' amounts.
   *  - AddMultipliedTotal(`add_multiplied_total`):
   *    For every modifier, multiplies the current value of the attribute by `(1 + x)`,
   *    where `x` is the amount of the particular modifier.
   */
  operation?: AttributeOperation,
  /**
   * Value:
   *
   *  - Mainhand(`mainhand`)
   *  - Offhand(`offhand`)
   *  - Head(`head`)
   *  - Chest(`chest`)
   *  - Legs(`legs`)
   *  - Feet(`feet`)
   *  - Hand(`hand`)
   *  - Armor(`armor`)
   *  - Any(`any`)
   *  - Body(`body`)
   *  - Saddle(`saddle`)
   */
  slot?: EquipmentSlotGroup,
}

export type BundleContentsPredicate = {
  items?: CollectionPredicate<ItemPredicate>,
}

export type CollectionPredicate<P extends NBTObject> = {
  /**
   * A list of tests. For each test, there must be at least one entry whose contents match exactly.
   */
  contains?: Array<P>,
  count?: Array<{
    /**
     * The contents an entry's text must match exactly.
     */
    test: P,
    /**
     * The number of entries that must match the test.
     */
    count: MinMaxBounds<NBTInt>,
  }>,
  /**
   * When set, total number of entries in the this collection.
   */
  size?: MinMaxBounds<NBTInt>,
}

export type ContainerPredicate = {
  items?: CollectionPredicate<ItemPredicate>,
}

export type FireworkExplosionPredicate = {
  /**
   * Value:
   *
   *  - SmallBall(`small_ball`)
   *  - LargeBall(`large_ball`)
   *  - Star(`star`)
   *  - Creeper(`creeper`)
   *  - Burst(`burst`)
   */
  shape?: FireworkShape,
  has_twinkle?: boolean,
  has_trail?: boolean,
}

export type FireworksPredicate = {
  explosions?: CollectionPredicate<FireworkExplosionPredicate>,
  flight_duration?: MinMaxBounds<NBTInt>,
}

export type ItemDamagePredicate = {
  damage?: MinMaxBounds<NBTInt>,
  durability?: MinMaxBounds<NBTInt>,
}

export type JukeboxPlayablePredicate = {
  song?: ((
      | Registry['minecraft:jukebox_song'] | `#${string}:${string}` | TagClass<'jukebox_song'> | JukeboxSongClass)
      | Array<(Registry['minecraft:jukebox_song'] | JukeboxSongClass)>),
}

export type PotionsPredicate = {
  potions?: PotionTypeMatch,
  effects?: CollectionPredicate<EntityEffectsPredicate>,
}

export type PotionTypeMatch = ((
  | Registry['minecraft:potion'] | `#${Registry['minecraft:tag/potion']}` | TagClass<'potion'>)
  | Array<Registry['minecraft:potion']>)

export type TrimPredicate = {
  material?: ((
      | Registry['minecraft:trim_material'] | `#${string}:${string}` | TagClass<'trim_material'> | TrimMaterialClass)
      | Array<(Registry['minecraft:trim_material'] | TrimMaterialClass)>),
  pattern?: ((
      | Registry['minecraft:trim_pattern'] | `#${string}:${string}` | TagClass<'trim_pattern'> | TrimPatternClass)
      | Array<(Registry['minecraft:trim_pattern'] | TrimPatternClass)>),
}

export type WritableBookPredicate = {
  /**
   * Matches the raw text, instead of filtered.
   */
  pages?: CollectionPredicate<string>,
}

export type WrittenBookPredicate = {
  /**
   * Matches the raw text, instead of filtered.
   */
  pages?: CollectionPredicate<Text>,
  author?: string,
  title?: string,
  generation?: MinMaxBounds<NBTInt>,
  resolved?: boolean,
}
type DataComponentPredicateDispatcherMap = {
  'attribute_modifiers': DataComponentPredicateAttributeModifiers,
  'minecraft:attribute_modifiers': DataComponentPredicateAttributeModifiers,
  'bundle_contents': DataComponentPredicateBundleContents,
  'minecraft:bundle_contents': DataComponentPredicateBundleContents,
  'container': DataComponentPredicateContainer,
  'minecraft:container': DataComponentPredicateContainer,
  'custom_data': DataComponentPredicateCustomData,
  'minecraft:custom_data': DataComponentPredicateCustomData,
  'damage': DataComponentPredicateDamage,
  'minecraft:damage': DataComponentPredicateDamage,
  'enchantments': DataComponentPredicateEnchantments,
  'minecraft:enchantments': DataComponentPredicateEnchantments,
  'firework_explosion': DataComponentPredicateFireworkExplosion,
  'minecraft:firework_explosion': DataComponentPredicateFireworkExplosion,
  'fireworks': DataComponentPredicateFireworks,
  'minecraft:fireworks': DataComponentPredicateFireworks,
  'jukebox_playable': DataComponentPredicateJukeboxPlayable,
  'minecraft:jukebox_playable': DataComponentPredicateJukeboxPlayable,
  'potion_contents': DataComponentPredicatePotionContents,
  'minecraft:potion_contents': DataComponentPredicatePotionContents,
  'stored_enchantments': DataComponentPredicateStoredEnchantments,
  'minecraft:stored_enchantments': DataComponentPredicateStoredEnchantments,
  'trim': DataComponentPredicateTrim,
  'minecraft:trim': DataComponentPredicateTrim,
  'villager/variant': DataComponentPredicateVillagerVariant,
  'minecraft:villager/variant': DataComponentPredicateVillagerVariant,
  'writable_book_content': DataComponentPredicateWritableBookContent,
  'minecraft:writable_book_content': DataComponentPredicateWritableBookContent,
  'written_book_content': DataComponentPredicateWrittenBookContent,
  'minecraft:written_book_content': DataComponentPredicateWrittenBookContent,
}
type DataComponentPredicateKeys = keyof DataComponentPredicateDispatcherMap
type DataComponentPredicateFallback = (
  | DataComponentPredicateAttributeModifiers
  | DataComponentPredicateBundleContents
  | DataComponentPredicateContainer
  | DataComponentPredicateCustomData
  | DataComponentPredicateDamage
  | DataComponentPredicateEnchantments
  | DataComponentPredicateFireworkExplosion
  | DataComponentPredicateFireworks
  | DataComponentPredicateJukeboxPlayable
  | DataComponentPredicatePotionContents
  | DataComponentPredicateStoredEnchantments
  | DataComponentPredicateTrim
  | DataComponentPredicateVillagerVariant
  | DataComponentPredicateWritableBookContent
  | DataComponentPredicateWrittenBookContent
  | DataComponentPredicateFallbackType)
export type DataComponentPredicateFallbackType = never
type DataComponentPredicateAttributeModifiers = AttributeModifiersPredicate
type DataComponentPredicateBundleContents = BundleContentsPredicate
type DataComponentPredicateContainer = ContainerPredicate
type DataComponentPredicateCustomData = CustomData
type DataComponentPredicateDamage = ItemDamagePredicate
type DataComponentPredicateEnchantments = Array<EnchantmentPredicate>
type DataComponentPredicateFireworkExplosion = FireworkExplosionPredicate
type DataComponentPredicateFireworks = FireworksPredicate
type DataComponentPredicateJukeboxPlayable = JukeboxPlayablePredicate
type DataComponentPredicatePotionContents = PotionTypeMatch
type DataComponentPredicateStoredEnchantments = Array<EnchantmentPredicate>
type DataComponentPredicateTrim = TrimPredicate
type DataComponentPredicateVillagerVariant = ((
  | Registry['minecraft:villager_type'] | `#${string}:${string}` | TagClass<'villager_type'>)
  | Array<Registry['minecraft:villager_type']>)
type DataComponentPredicateWritableBookContent = WritableBookPredicate
type DataComponentPredicateWrittenBookContent = WrittenBookPredicate
export type SymbolDataComponentPredicate<CASE extends
  | 'map'
  | 'keys'
  | '%fallback'
  | '%none'
  | '%unknown' = 'map'> = CASE extends 'map'
  ? DataComponentPredicateDispatcherMap
  : CASE extends 'keys'
    ? DataComponentPredicateKeys
    : CASE extends '%fallback'
      ? DataComponentPredicateFallback
      : CASE extends '%unknown' ? DataComponentPredicateFallbackType : never
